<?php

    include '../config/config.php';
    
    class update extends Connection{

        public function managupdate(){
        
            $id = $_POST['id'];
            $status = 1;

            $sqlinsert = " UPDATE tbl_dictionary SET status = ? WHERE id = '".$id."'";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([$status]);    

        }

    }

    $updatedata = new update();
    $updatedata->managupdate();

?>



