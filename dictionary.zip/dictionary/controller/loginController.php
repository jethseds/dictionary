<?php
  
  include '../config/config.php';
  session_start();
  
  class login extends Connection{
  
    public function loginuser(){ 

      if (isset($_POST['submit'])) {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $sqlselect_users = "SELECT * FROM users WHERE username = ?";
        $stmt = $this->conn()->prepare($sqlselect_users);
        $stmt->execute([$username]);

        if ($stmt->rowcount() > 0) {

          $row = $stmt->fetch();

          if (password_verify($password, $row['password'])) {
            
            if ($row['type'] == 0) {

              header('location:../private/encoder/dashboard.php?dashboard=dashboard');
              $_SESSION['id'] = $row['id'];
              $_SESSION['fullname'] = $row['fullname'];
              $_SESSION['position'] = 'encoder';

            } else if ($row['type'] == 1) {

              header('location:../private/admin/users.php?users=users');
              $_SESSION['id'] = $row['id'];
              $_SESSION['fullname'] = $row['fullname'];
              $_SESSION['position'] = 'admin';

            } else if ($row['type'] == 2) {

              header('location:../private/publisher/dashboard.php?dashboard=dashboard');
              $_SESSION['id'] = $row['id'];
              $_SESSION['fullname'] = $row['fullname'];
              $_SESSION['position'] = 'publisher';

            } else {

                echo "<script type='text/javascript'>alert('Youre Account Are not Verified');</script>";
                echo "<script>window.location.href='../login/index.php';</script>";

            }

          }

        } else {

            echo "<script type='text/javascript'>alert('Invalid Username And Password');</script>";
            echo "<script>window.location.href='../login/index.php';</script>";

        } 
       
      } 
         
    }

  }

  $loginrun = new login();
  $loginrun->loginuser();

?>



