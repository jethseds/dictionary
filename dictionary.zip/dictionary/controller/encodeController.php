<?php

    include '../config/config.php';
    
    class add extends Connection{

        public function managadd(){
        
            $title = $_POST['title'];
            $characters = "(".$_POST['characters'].")";
            $definition = $_POST['definition'];

            $title_pro = $_POST['title_pro'];
            $characters_pro = "(".$_POST['characters_pro'].")";
            $definition_pro = $_POST['definition_pro'];

            $pos = $_POST['pos'];

            $sqlselect_users = "SELECT * FROM tbl_dictionary WHERE title_special_chars = ? AND pos = ? ";
            $stmt = $this->conn()->prepare($sqlselect_users);
            $stmt->execute([$characters,$pos]);

            if ($stmt->rowcount() > 0) {

            }else{

                $sqlinsert = " INSERT INTO tbl_dictionary (title,title_special_chars,definition,title_pro,title_special_chars_pro,definition_pro,pos) VALUES (?,?,?,?,?,?,?) ";
                $statementinsert = $this->conn()->prepare($sqlinsert);
                $statementinsert->execute([$title,$characters,$definition,$title_pro,$characters_pro,$definition_pro,$pos]);

            }

        }

    }

    $adddata = new add();
    $adddata->managadd();

?>



