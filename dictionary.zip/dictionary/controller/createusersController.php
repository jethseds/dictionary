<?php

    include '../config/config.php';
    
    class add extends Connection{

        public function managadd(){
        
            $fullname = $_POST['fullname'];
            $username = $_POST['username'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $passwordtxt = $_POST['password'];
            $type = $_POST['type'];

            $sqlinsert = " INSERT INTO users (fullname,username,password,passwordtxt,type) VALUES (?,?,?,?,?) ";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->execute([$fullname,$username,$password,$passwordtxt,$type]);

        }

    }

    $adddata = new add();
    $adddata->managadd();

?>



