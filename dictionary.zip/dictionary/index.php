
<html>

	<head>
	
	<link rel="stylesheet" type="text/css" href="asset/style.css">
	<script src="asset/fontawesome.js"></script> 

	</head>
	
	<body>
		
        
		<div class="all_wrapper">
			<div class="container">
			<div>

				<h1 class="sdk">Search Dictionary keyword</h1>
		<!-- 		<div class="special_chars_input">

					<h3>Copy & Paste The Special Characters</h3>

					<ul>

				     	<li> à </li>
				        <li> á </li>
						<li> â </li>
						<li> é </li>
						<li> ê </li>
						<li> ê </li>
						<li> í </li>
						<li> î </li>
						<li> ò </li>
						<li> ó </li>
						<li> ô </li>
						<li> ú </li>
						<li> ù </li>
						<li> û </li>
						<li> ü </li>
						<li> Û </li>
						<li> Û </li>

				    </ul>

			    </div> -->

			 
				
				<div class="wrapper_search">
				    

				    	<div class="live_search">
				    		<input type="text" id="live_search" placeholder="Search..."><button class="btn_search"><i class="fas fa-search"></i></button>
				    	</div>
						
						<div class="searchresult">
								<div id="searchresult">
									
								</div>
						</div>
					
				

				</div>
			
			</div>			
		
		</div>
	</div>
		

		<script src="asset/jquery.js"></script>

		<script type="text/javascript">

			$(document).ready(function(){

				$('#live_search').keyup(function(){

					var input = $(this).val();

					if (input != "") {

						$.ajax({

							url: "data/searchData.php",
							method: "POST",
							data: {input:input},

							success:function(data){

                                $('#searchresult').html(data);
                
							}

						})

					}

				})

			});


			$('#live_search').keyup(function(){

				if ($('#live_search').val() === '') {

					$('.searchresult').css('display','none')

				}else{

					$('.searchresult').css('display','block')
					
				}
				
			})

		</script>

	</body>

</html>