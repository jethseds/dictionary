
<!-- Title -->
<title>Admin Panel</title>

<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css">

<!-- Loader CSS -->
  <link rel="stylesheet" href="../css/loader.css">

<!-- Sidebar CSS -->
<link rel="stylesheet" href="../css/sidebar.css">

<!-- Top Navbar CSS -->
<link rel="stylesheet" href="../css/topnavbar.css">

<!-- Whole Container Content CSS -->
<link rel="stylesheet" href="../css/whole_container_content.css">

<!-- Transition CSS -->
<link rel="stylesheet" href="../css/transition.css">

<!-- Position CSS -->
<link rel="stylesheet" href="../css/position.css">

<!-- Style CSS -->
<link rel="stylesheet" href="../css/style.css">

<!-- Media CSS -->
<link rel="stylesheet" href="../css/media.css">
