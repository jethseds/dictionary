<?php

    include '../../config/config.php';

    // Class Function
    class users extends Connection{ 

	        // users Function
        public function manageusers(){ 

            $sql = "SELECT * FROM users WHERE type = 0 OR type = 2";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td><?php echo $row['fullname']; ?></td> 
                    <td><?php echo $row['username']; ?></td> 
                    <td><?php echo $row['password']; ?></td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $users = new users();
    $users->manageusers();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>