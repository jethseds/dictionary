
<div class="col-lg-12 mt-4">

	<div class="card border-0 p-2 card_chart">

		<div class="card-body">
			
			<h5 class="m-3">Sales report</h5>
			<canvas id="myChart" width="600" height="210"></canvas>

		</div>

	</div>

</div>
