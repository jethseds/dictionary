
<?php include '../../session.php'; ?>
<?php include '../../config/config.php'; ?>

<?php

     class data extends Connection{ 

        public function managedata(){   

            $totalwor = $this->conn()->query(" SELECT COUNT(id) AS totalwor FROM tbl_dictionary ")->fetch();
            $totalpn = $this->conn()->query(" SELECT COUNT(id) AS totalpn FROM tbl_dictionary WHERE pos = 'PN' ")->fetch();
            $totalpl = $this->conn()->query(" SELECT COUNT(id) AS totalpl FROM tbl_dictionary WHERE pos = 'PL' ")->fetch();
            $totalps = $this->conn()->query(" SELECT COUNT(id) AS totalps FROM tbl_dictionary WHERE pos = 'PS' ")->fetch();
            $totalph = $this->conn()->query(" SELECT COUNT(id) AS totalph FROM tbl_dictionary WHERE pos = 'PH' ")->fetch();
            $totalpt = $this->conn()->query(" SELECT COUNT(id) AS totalpt FROM tbl_dictionary WHERE pos = 'PT' ")->fetch();
            $totalpp = $this->conn()->query(" SELECT COUNT(id) AS totalpp FROM tbl_dictionary WHERE pos = 'PP' ")->fetch();
            $totalpg = $this->conn()->query(" SELECT COUNT(id) AS totalpg FROM tbl_dictionary WHERE pos = 'PG' ")->fetch();
            $totalpa = $this->conn()->query(" SELECT COUNT(id) AS totalpa FROM tbl_dictionary WHERE pos = 'PA' ")->fetch();
            $totalar = $this->conn()->query(" SELECT COUNT(id) AS totalar FROM tbl_dictionary WHERE pos = 'AR' ")->fetch();
            $totalpb = $this->conn()->query(" SELECT COUNT(id) AS totalpb FROM tbl_dictionary WHERE pos = 'PB' ")->fetch();

?>





<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;overflow-x: hidden;overflow-y: hidden;">

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>


            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="row p-4">
                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_name">

                            <h5 class="text-white font-weight-bold">Welcome <?php echo $_SESSION['fullname']; ?>! <span class="float-right"><i class="fas fa-user-circle"></i></span></h5>
                            <label class="text-white"><?php echo date('F d, Y'); ?></label>

                            <button class="mt-4 view_more">view more</button>

                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of Words</h6>

                            <button class="view_more view_more_color">Wor</button>

                            <div class="mt-1 h5">Total : <?php echo $totalwor['totalwor']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PN - Noun Words</h6>

                            <button class="view_more view_more_color">PN</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpn['totalpn']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PL - Pronoun Words</h6>

                            <button class="view_more view_more_color">PL</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpl['totalpl']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PS - Adjective Words</h6>

                            <button class="view_more view_more_color">PS</button>

                            <div class="mt-1 h5">Total : <?php echo $totalps['totalps']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PH - Verb Words</h6>

                            <button class="view_more view_more_color">PH</button>

                            <div class="mt-1 h5">Total : <?php echo $totalph['totalph']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PT - Adverb Words</h6>

                            <button class="view_more view_more_color">PT</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpt['totalpt']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PP - Conjunction Words</h6>

                            <button class="view_more view_more_color">PP</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpp['totalpp']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PG - Preposition Words</h6>

                            <button class="view_more view_more_color">PG</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpg['totalpg']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PA - Interjection Words</h6>

                            <button class="view_more view_more_color">PA</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpa['totalpa']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of AR - Article Words</h6>

                            <button class="view_more view_more_color">AR</button>

                            <div class="mt-1 h5">Total : <?php echo $totalar['totalar']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 mt-4">

                    <div class="card border-0 bg-transparent">

                        <div class="card-body card_employees">

                            <h6 class="font-weight-bold">Total Number of PB - Affix Words</h6>

                            <button class="view_more view_more_color">PB</button>

                            <div class="mt-1 h5">Total : <?php echo $totalpb['totalpb']; ?> &nbsp;&nbsp;<!-- <span class="text-success"> + 3.55 % </span> --></div> 


                        </div>

                    </div>

                </div>

                <!-- <?php include 'chart/chart.php'; ?> -->

            </div>

        </div>


        <!-- JS -->
        <?php include 'footer.php'; ?>

    </body>

</html>

<?php 
            }

        }
 
    $test = new data();
    $test->managedata();

?>