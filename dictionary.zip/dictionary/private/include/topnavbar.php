<nav class="topnavbar">

  <a id="show_sidebar" class="navbar-brand text-dark" href="#"><i class="fas fa-bars"></i></a>
  <a id="show_sidebar_mobile" class="navbar-brand text-dark" href="#"><i class="fas fa-bars"></i></a>

  <button class="navbar-toggler" type="button">

    <span class="navbar-toggler-icon"></span>

  </button>

    <ul class="navbar-nav mr-auto float-right">

      <li id="show_dropdown" class="nav-item show_dropdown">

        <a class="navbar-brand text-dark" href="#">

          <i class="fas fa-user-circle"></i>

        </a>

        <div class="dropdown">

          <ul class="pl-0">

            <li>

              <a href="#">

                <strong>Juan Dela Cruz</strong>
                <br>
                
                <?php 

                  if ($_SESSION['position'] == 'admin'){
                    echo "Admin";
                  } else if ($_SESSION['position'] == 'encoder') {
                    echo "Encoder";
                  } else {
                    echo "Publisher";
                  }
                
                ?>

              </a>

            </li>
<!-- 
            <li>

              <a href="profile.php"><i class="fas fa-address-card"></i> &nbsp; Profile</a>

            </li> -->

            <li>

              <a href="../../login/logout.php"><i class="fas fa-sign-out"></i> &nbsp; Logout</a>

            </li>

          </ul>

        </div>

      </li>

    </ul>

</nav>