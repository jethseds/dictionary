
<div class="wrapper_sidebar">
	
	<div class="sidebar_body">
		
		<div class="list-group">
		    
		    <a href="#" class="list-group-item border-0 list-group-item-action p-4" aria-current="true">
			   
			    <span class="logo"><i class="fas fa-copyright"></i> 
			    	
			    	<?php 

				    	if ($_SESSION['position'] == 'admin'){
				    		echo "Admin";
				    	} else if ($_SESSION['position'] == 'encoder') {
				    		echo "Encoder";
				    	} else {
				    		echo "Publisher";
				    	}
			    	
			    	?>

			    </span>

		    </a>


		    <?php if ($_SESSION['position'] != 'admin'): ?>

		    <a href="dashboard.php?dashboard=dashboard" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['dashboard'])) { echo "active"; }  ?>"
		        

		    aria-current="true">
			   
			    <i class="fas fa-tachometer-alt"></i> &nbsp;&nbsp; Dashboard

		    </a>

		    <?php endif; ?>

		    <?php if ($_SESSION['position'] == 'admin'): ?>

		    <a href="users.php?users=users" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['users'])) { echo "active"; }  ?>">

			    <i class="fas fa-table"></i> &nbsp;&nbsp; Users

		    </a>

			<?php endif; ?>

			<?php if ($_SESSION['position'] == 'publisher'): ?>

		    <a href="new_encode.php?new_encode=new_encode" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['new_encode'])) { echo "active"; }  ?>">

			    <i class="fas fa-table"></i> &nbsp;&nbsp; New Encode

		    </a>

		    <a href="old_encode.php?old_encode=old_encode" class="list-group-item font-weight-bold border-0 list-group-item-action p-3 mt-1 mb-1 <?php if (isset($_GET['old_encode'])) { echo "active"; }  ?>">

			    <i class="fas fa-table"></i> &nbsp;&nbsp; Old Encode

		    </a>

		    <?php endif; ?>
		
		</div>

	</div>

</div>
