<?php

    include '../../config/config.php';

    // Class Function
    class users extends Connection{ 

	        // users Function
        public function manageusers(){ 

            $sql = "SELECT * FROM tbl_dictionary WHERE status = 0";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td style="display: none;"><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td> 
                    <td><?php echo $row['title_special_chars']; ?></td> 
                    <td><?php echo substr($row['definition'], 0, 50)."..."; ?></td> 
                    <td><?php echo $row['title_pro']; ?></td> 
                    <td><?php echo $row['title_special_chars_pro']; ?></td> 
                    <td><?php echo substr($row['definition_pro'], 0, 50)."..."; ?></td> 
                    <td><?php echo $row['pos']; ?></td> 
                    <td><button id="published" class="view_more" style="background-color: #11a800;color: #fff;">Published</button></td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $users = new users();
    $users->manageusers();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>