<?php

    include '../../config/config.php';

    // Class Function
    class users extends Connection{ 

	        // users Function
        public function manageusers(){ 

            $sql = "SELECT * FROM tbl_dictionary WHERE status = 1";
            $stmt = $this->conn()->query($sql);
            $id = 1;

            while ($row = $stmt->fetch()) { ?>

                <tr class="gradeU">

                    <td><?php echo $id; ?></td>
                    <td><?php echo $row['title']; ?></td> 
                    <td><?php echo $row['title_special_chars']; ?></td> 
                    <td><?php echo substr($row['definition'], 0, 50)."..."; ?></td> 
                    <td><?php echo $row['title_pro']; ?></td> 
                    <td><?php echo $row['title_special_chars_pro']; ?></td> 
                    <td><?php echo substr($row['definition_pro'], 0, 50)."..."; ?></td> 
                    <td><?php echo $row['pos']; ?></td> 

                </tr>

<?php 
                $id++;  

            }

	    }
        
	}

    $users = new users();
    $users->manageusers();
   
?>


<script>

       $(document).ready(function() {

        $('.dataTables-example').DataTable({ destroy: true,  retrieve: true, });
      
        });
       
</script>