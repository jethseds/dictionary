
<?php include '../../session.php'; ?>
<?php include '../../config/config.php'; ?>

<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;">

        <div class="success">Successfully Encode Added :)</div>

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>


            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="row p-4">

                <div class="wrapper">
        
        <h2>Dictionary Encode</h2>
        <br>
        <br>
        <h3>Tagalog</h3>
        <br>
        <form method="POST">

            <input type="text" name="title" id="title" class="title" placeholder="Title...">

            <div class="special_chars">

                <input type="button" class="char" value="à">
                <input type="button" class="char" value="á">
                <input type="button" class="char" value="â">
                <input type="button" class="char" value="é">
                <input type="button" class="char" value="ê">
                <input type="button" class="char" value="ê">
                <input type="button" class="char" value="í">
                <input type="button" class="char" value="î">
                <input type="button" class="char" value="ò">
                <input type="button" class="char" value="ó">
                <input type="button" class="char" value="ô">
                <input type="button" class="char" value="ú">
                <input type="button" class="char" value="ù">
                <input type="button" class="char" value="û">
                <input type="button" class="char" value="ü">
                <input type="button" class="char" value="Û">
                <input type="button" class="char" value="Û">

            </div>

            <input type="text" name="characters" id="characters" class="characters" placeholder="Title Special Characters...">
            <textarea name="definition" id="definition" rows="15" placeholder="Definition..."></textarea>
        

        </form>

        <br>
        <h3>English</h3>
        <br>
        <form method="POST">

            <input type="text" name="title_pro" id="title_pro" class="title" placeholder="Title...">

            <div class="special_chars">

                <input type="button" class="char_pro" value="à">
                <input type="button" class="char_pro" value="á">
                <input type="button" class="char_pro" value="â">
                <input type="button" class="char_pro" value="é">
                <input type="button" class="char_pro" value="ê">
                <input type="button" class="char_pro" value="ê">
                <input type="button" class="char_pro" value="í">
                <input type="button" class="char_pro" value="î">
                <input type="button" class="char_pro" value="ò">
                <input type="button" class="char_pro" value="ó">
                <input type="button" class="char_pro" value="ô">
                <input type="button" class="char_pro" value="ú">
                <input type="button" class="char_pro" value="ù">
                <input type="button" class="char_pro" value="û">
                <input type="button" class="char_pro" value="ü">
                <input type="button" class="char_pro" value="Û">
                <input type="button" class="char_pro" value="Û">

            </div>

            <input type="text" name="characters_pro" id="characters_pro" class="characters" placeholder="Title Special Characters...">
            <textarea name="definition_pro" id="definition_pro" rows="15" placeholder="Definition..."></textarea>

            <select name="pos" id="pos">
                <option value="">Select Part Of Speech</option>
                <option value="PN">PN - noun </option>
                <option value="PL">PL - pronoun</option>
                <option value="PS">PS - adjective</option>
                <option value="PH">PH - verb</option>
                <option value="PT">PT - adverb</option>
                <option value="PP">PP - conjunction</option>
                <option value="PG">PG - preposition</option>
                <option value="PA">PA - interjection</option>
                <option value="AR">AR - article</option>
                <option value="PB">PB – affix</option>
            </select>



        </form> 

        <div style="text-align: right;">

            <input type="button" name="submit" class="submit" value="Submit">

        </div>

    </div>
            

                <!-- <?php include 'chart/chart.php'; ?> -->

            </div>

        </div>


        <!-- JS -->
        <?php include 'footer.php'; ?>

        <script>

                $(".char").click( function() {
                  
                    $('#characters').val($('#characters').val()+$(this).val());
                   
                });

                $(".char_pro").click( function() {
                  
                    $('#characters_pro').val($('#characters_pro').val()+$(this).val());
                   
                });

                $(".submit").click( function() {
                    
                    $.ajax({

                        url: '../../controller/encodeController.php',
                        type: 'POST',
                        cachhe: false,
                        data: {

                            title: $('#title').val(),
                            characters: $('#characters').val(),
                            definition: $('#definition').val(),
                            title_pro: $('#title_pro').val(),
                            characters_pro: $('#characters_pro').val(),
                            definition_pro: $('#definition_pro').val(),
                            pos: $('#pos').val()
                        },
                        success: function() {

                            $( ".success" ).first().fadeIn( "slow" );

                            setTimeout(function(){

                                $( ".success" ).first().fadeOut( "slow" );

                            },2000);

                            $('#title').val('')
                            $('#characters').val('')
                            $('#definition').val('')
                            $('#title_pro').val('')
                            $('#characters_pro').val('')
                            $('#definition_pro').val('')
                            $('#pos').val('')

                        }

                    })
                
                });
            
        </script>

    </body>

</html>

