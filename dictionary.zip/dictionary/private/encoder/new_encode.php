
<?php include '../../session.php'; ?>

<!doctype html>

<html lang="en">
    
    <head>

        <!-- CSS -->
        <?php require_once 'header.php'; ?>
            
    </head>
    
    <body style="background-color: #ecf2fd;overflow-x: hidden;">

        <div class="success">Successfully Encode Added :)</div>

        <div style="display: flex;">

            <!-- Sidebar -->
            <?php include '../include/sidebar.php'; ?>


            <!-- Top Navbar -->
            <?php include '../include/topnavbar.php'; ?>

        </div>

        <div class="whole_container_content">

            <div class="header_title">

                <h4>New Encode</h4>

            </div>

            <div class="row p-4">
                
                <div class="col-lg-12 m-auto">
                
                    <div class="card border-0 card_table">


                
                        <div class="card-body">

                           <!--  <div style="text-align: right;"><button class="btn btn-primary create_user" data-toggle="modal" data-target="#staticBackdrop">Create User</button></div> -->

                            <div id="style-1" class="table-responsive">
                                
                                <table class="table table-striped table-bordered table-sm dataTables-example" width="100%">
                                 
                                  <thead>
                                  
                                    <tr>

                                        <th class="th-sm">Id</th>
                                        <th class="th-sm">Title</th>
                                        <th class="th-sm">Title Special Chars</th>
                                        <th class="th-sm">Definition</th>
                                        <th class="th-sm">Title Pronunciation</th>
                                        <th class="th-sm">Title Special Chars Pronunciation</th>
                                        <th class="th-sm">Definition Pronunciation</th>
                                        <th class="th-sm">Part Of Speech</th>
                                    
                                    </tr>
                                  </thead>

                                  <tbody id="table">

                                  </tbody>

                                </table>

                            </div>

                        </div>
                
                    </div>
                
                </div>

            </div>

        </div>

        <!-- JS -->
        <?php include 'footer.php'; ?>

  

        <script>


            $.ajax({

                url: "new_encode_data.php",
                type: "POST",
                cache:false,

                success: function(dataResult){

                    $('#table').html(dataResult)

                }

            })
            

            // $('#create_user').click(function(){

            //     $.ajax({

            //         url: "../../controller/createusersController.php",
            //         type: "POST",
            //         cache: false,

            //         data: {

            //             fullname: $('#fullname').val(),
            //             username: $('#username').val(),
            //             password: $('#password').val(),
            //             type: $('#type').val()

            //         },

            //         success: function(dataResult){

            //             $( ".success" ).first().fadeIn( "slow" );

            //             setTimeout(function(){

            //                 $( ".success" ).first().fadeOut( "slow" );

            //             },2000);

            //             $('#fullname').val('')
            //             $('#username').val('')
            //             $('#password').val('')

                
            //             $.ajax({

            //                 url: "users_data.php",
            //                 type: "POST",
            //                 cache: false,
                            

            //                 success: function(dataResult){

            //                     $('#table').html(dataResult)

            //                 }

            //             })

            //         }

            //     })

            // })

        </script>

    </body>

</html>