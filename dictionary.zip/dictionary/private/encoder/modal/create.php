
<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="staticBackdropLabel">Create User</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <form method="POST">

        <div class="modal-body">

          <div class="form-group">

            <label>Fullname</label>
            <input type="text" name="fullname" id="fullname" class="form-control" placeholder="Fullname">

          </div>

          <div class="form-group">

            <label>Username</label>
            <input type="text" name="username" id="username" class="form-control" placeholder="Username">

          </div>

          <div class="form-group">

            <label>Password</label>
            <input type="text" name="password" id="password" class="form-control" placeholder="Password">

          </div>

        </div>

      </form>
      

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="create_user" class="btn btn-primary create_user_modal"data-dismiss="modal">Yes</button>

      </div>

    </div>

  </div>

</div>