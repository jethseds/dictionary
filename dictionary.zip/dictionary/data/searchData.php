<?php

    include '../config/config.php';
    
     class data extends Connection{ 

            // data Function
        public function managedata(){   

            $input = $_POST['input'];
            $sql = "SELECT * FROM tbl_dictionary WHERE status = 1 AND title LIKE '{$input}%' ORDER BY title ASC";
            $stmt = $this->conn()->query($sql);
            
                while ($row = $stmt->fetch()) { ?>

                    <br>

                    <div style="display: flex;">

                        <label style="font-weight: bold;"><?php echo $row['title']; ?><span style="margin-left: 4px;">:</span></label>

                        <div style="margin-left: 4px;">

                            <label style="font-size: 15px;"> <?php echo $row['title_special_chars']; ?> <i><?php echo $row['pos']; ?></i></label> <?php echo $row['definition']; ?>
                       
                        </div>

                    </div>

                    <br>

                    <div style="display: flex;">

                        <label style="font-weight: bold;"><?php echo $row['title_pro']; ?><span style="margin-left: 4px;">:</span></label>

                        <div style="margin-left: 4px;">

                            <label style="font-size: 15px;"> <?php echo $row['title_special_chars_pro']; ?> </label><?php echo $row['definition_pro']; ?>
                       
                        </div>

                    </div>  

                <?php }  

            }

        }

 
    $test = new data();
    $test->managedata();

?>



